import numpy as np
import openvr
"""
This module provides a set of utility functions for retrieving, transforming,
and using VR camera and controller pose data via the OpenVR API.
It is designed for scenarios such as stereo camera parameter extraction,
intrinsic/extrinsic calibration, spatial transformation, and stereo rectification
in VR environments.
"""
def init_openvr():
    global vr_system
    openvr.init(openvr.VRApplication_Utility)
    vr_system = openvr.VRSystem()

def shutdown_openvr():
    openvr.shutdown()

def get_fov():
    openvr.init(openvr.VRApplication_Scene)
    vr_system = openvr.VRSystem()

    left_proj_raw = vr_system.getProjectionRaw(openvr.Eye_Left)
    right_proj_raw = vr_system.getProjectionRaw(openvr.Eye_Right)

    def compute_fov(proj_raw):
        left, right, bottom, top = proj_raw
        fov_h = np.degrees(np.abs(np.arctan(right) - np.arctan(left)))
        fov_v = np.degrees(np.abs(np.arctan(top) - np.arctan(bottom)))
        return fov_h, fov_v

    FOV_left = compute_fov(left_proj_raw)
    FOV_right = compute_fov(right_proj_raw)
    return {
        "FOV_left": FOV_left,
        "FOV_right": FOV_right
    }

def get_projection():
    left_projection = vr_system.getProjectionMatrix(openvr.Eye_Left, 0.1, 100.0)
    right_projection = vr_system.getProjectionMatrix(openvr.Eye_Right, 0.1, 100.0)

    def convert_projection_matrix(projection):
        projection_np = np.array([
            [projection.m[0][0], projection.m[0][1], projection.m[0][2], projection.m[0][3]],
            [projection.m[1][0], projection.m[1][1], projection.m[1][2], projection.m[1][3]],
            [projection.m[2][0], projection.m[2][1], projection.m[2][2], projection.m[2][3]],
            [projection.m[3][0], projection.m[3][1], projection.m[3][2], projection.m[3][3]]
        ], dtype=np.float32)

        return projection_np
    left_projection_np = convert_projection_matrix(left_projection)
    right_projection_np = convert_projection_matrix(right_projection)

    return left_projection_np, right_projection_np

def get_visual_controller_pos():
    init_openvr()
    controller_indexes = []
    for i in range(openvr.k_unMaxTrackedDeviceCount):
        if vr_system.getTrackedDeviceClass(i) == openvr.TrackedDeviceClass_Controller:
            controller_indexes.append(i)

    if not controller_indexes:
        return None
    poses = vr_system.getDeviceToAbsoluteTrackingPose(
        openvr.TrackingUniverseStanding, 0, openvr.k_unMaxTrackedDeviceCount
    )

    for controller_id in controller_indexes:
        pose = poses[controller_id]
        if controller_id == 1:
            matrix = pose.mDeviceToAbsoluteTracking
            x, y, z = matrix[0][3], matrix[1][3], matrix[2][3]
            return (x, y, z)

def calculate_world_position_2(
        left_point: np.ndarray,
        right_point: np.ndarray,
        left_projection: np.ndarray,
        right_projection: np.ndarray,
        left_eye_to_head: np.ndarray,
        right_eye_to_head: np.ndarray,
        hmd_to_world: np.ndarray
) -> np.ndarray:

    left_eye_origin = np.array([0.0, 0.0, 0.0, 1.0])
    right_eye_origin = np.array([0.0, 0.0, 0.0, 1.0])

    left_eye_head = left_eye_to_head @ left_eye_origin
    right_eye_head = right_eye_to_head @ right_eye_origin

    left_eye_head /= left_eye_head[3]
    right_eye_head /= right_eye_head[3]

    eye_separation = np.linalg.norm(right_eye_head[:3] - left_eye_head[:3])

    left_ndc = np.array([left_point[0], left_point[1], -1.0, 1.0])
    left_eye_dir = np.linalg.inv(left_projection) @ left_ndc
    left_eye_dir /= left_eye_dir[3]
    left_eye_dir = left_eye_dir[:3] - np.array([0.0, 0.0, 0.0])
    left_eye_dir /= np.linalg.norm(left_eye_dir)


    right_ndc = np.array([right_point[0], right_point[1], -1.0, 1.0])
    right_eye_dir = np.linalg.inv(right_projection) @ right_ndc
    right_eye_dir /= right_eye_dir[3]
    right_eye_dir = right_eye_dir[:3] - np.array([0.0, 0.0, 0.0])
    right_eye_dir /= np.linalg.norm(right_eye_dir)

    left_dir_point = np.array([left_eye_dir[0], left_eye_dir[1], left_eye_dir[2], 0.0])
    right_dir_point = np.array([right_eye_dir[0], right_eye_dir[1], right_eye_dir[2], 0.0])

    left_head_dir = left_eye_to_head @ left_dir_point
    right_head_dir = right_eye_to_head @ right_dir_point

    left_head_dir = left_head_dir[:3]
    right_head_dir = right_head_dir[:3]
    left_head_dir /= np.linalg.norm(left_head_dir)
    right_head_dir /= np.linalg.norm(right_head_dir)

    cos_angle = np.dot(left_head_dir, right_head_dir)
    angle = np.arccos(np.clip(cos_angle, -1.0, 1.0))

    depth = eye_separation / (2 * np.tan(angle / 2))

    head_point = left_eye_head[:3] + depth * left_head_dir
    head_point_homogeneous = np.array([head_point[0], head_point[1], head_point[2], 1.0])
    world_point_homogeneous = hmd_to_world @ head_point_homogeneous
    world_point_homogeneous /= world_point_homogeneous[3]
    world_point = world_point_homogeneous[:3]
    return world_point

def eye_to_head():
    left_eye_to_head = vr_system.getEyeToHeadTransform(openvr.Eye_Left)
    right_eye_to_head = vr_system.getEyeToHeadTransform(openvr.Eye_Right)

    def convert_transform(mat):
        return np.array([
            [mat[0][0], mat[0][1], mat[0][2], mat[0][3]],
            [mat[1][0], mat[1][1], mat[1][2], mat[1][3]],
            [mat[2][0], mat[2][1], mat[2][2], mat[2][3]],
            [0, 0, 0, 1]
        ])

    left_eye_to_head_matrix = convert_transform(left_eye_to_head)
    right_eye_to_head_matrix = convert_transform(right_eye_to_head)

    return left_eye_to_head_matrix,right_eye_to_head_matrix

def hmd_to_world():
    poses = vr_system.getDeviceToAbsoluteTrackingPose(
        openvr.TrackingUniverseStanding, 0, openvr.k_unMaxTrackedDeviceCount
    )
    pose = poses[openvr.k_unTrackedDeviceIndex_Hmd]

    hmd_to_world_matrix = np.array([
        [pose.mDeviceToAbsoluteTracking[0][0], pose.mDeviceToAbsoluteTracking[0][1],
         pose.mDeviceToAbsoluteTracking[0][2], pose.mDeviceToAbsoluteTracking[0][3]],
        [pose.mDeviceToAbsoluteTracking[1][0], pose.mDeviceToAbsoluteTracking[1][1],
         pose.mDeviceToAbsoluteTracking[1][2], pose.mDeviceToAbsoluteTracking[1][3]],
        [pose.mDeviceToAbsoluteTracking[2][0], pose.mDeviceToAbsoluteTracking[2][1],
         pose.mDeviceToAbsoluteTracking[2][2], pose.mDeviceToAbsoluteTracking[2][3]],
        [0, 0, 0, 1]
    ])

    return hmd_to_world_matrix



