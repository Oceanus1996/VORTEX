import queue
import threading
from reprojection import calibrate_first_frame, get_corrected_projection
import remapping_motion, indle
import difflib
import numpy as np
from transformers import AutoProcessor, AutoModelForZeroShotObjectDetection
import torch.nn.functional as F
import cv2
import math
import torch

"""
Automated VR Object Detection, Tracking, and Controller Adjustment Script

This script integrates zero-shot object detection (Grounding DINO), depth estimation (MiDaS), and
OpenVR-based spatial control to automatically detect, track, and approach objects in a VR scene.
It supports robust dual-object tracking, depth-based controller movement, planar adjustment,
and visual feedback via real-time camera input.
"""

print("CUDA available:", torch.cuda.is_available())
print("CUDA vision:", torch.version.cuda)

detection_queue = queue.Queue(maxsize=1)
result_queue = queue.Queue(maxsize=2)
stop_signal = threading.Event()
model_id = "IDEA-Research/grounding-dino-tiny"
device = "cuda" if torch.cuda.is_available() else "cpu"

processor = AutoProcessor.from_pretrained(model_id)
model = AutoModelForZeroShotObjectDetection.from_pretrained(model_id).to(device)

global move_history
move_history = 10000

global redection_unsuccess , is_redection_success
redection_unsuccess = 0
is_redection_success = True

global prev_obj1_feature
prev_obj1_feature = {
    "features": None,
    "box": (0,0,0,0)
}
def fuzzy_match(a: str, b: str, thresh: float = 0.4) -> bool:

    return difflib.SequenceMatcher(None, a.lower(), b.lower()).ratio() > thresh

def compare_feature_with_candidates(old_feature, new_feature_vectors, object_name=None, similarity_threshold=0.6):
    """
    Compare the cosine similarity of a single old feature vector with multiple new feature vectors to find the best match.
    """
    print("compare_feature_with_candidates")

    if not new_feature_vectors or old_feature is None or old_feature["features"] is None:
        return None

    filtered_vectors = new_feature_vectors
    if object_name is not None:
        filtered_vectors = [v for v in new_feature_vectors if object_name.lower() in v["label"].lower()]

    if not filtered_vectors:
        return None

    best_match_idx = -1
    best_similarity = -1.0
    best_combined_score = -1.0

    for i, new_vec in enumerate(filtered_vectors):
        if new_vec["features"] is None:
            continue

        cos_sim = torch.mm(old_feature["features"], new_vec["features"].transpose(0, 1))
        similarity = (cos_sim.item() + 1) / 2


        if similarity < similarity_threshold:
            print(f"Candidate box #{i} feature similarity is too low: {similarity:.3f} < {similarity_threshold}")
            continue

        spatial_score = 0.5
        if "box" in old_feature and "box" in new_vec:
            x1, y1, w1, h1 = old_feature["box"]
            x2, y2, w2, h2 = new_vec["box"]

            cx1, cy1 = x1 + w1 / 2, y1 + h1 / 2
            cx2, cy2 = x2 + w2 / 2, y2 + h2 / 2

            dist = ((cx2 - cx1) ** 2 + (cy2 - cy1) ** 2) ** 0.5
            max_dist = 300
            spatial_score = max(0, 1 - (dist / max_dist))

            size_ratio = (w2 * h2) / (w1 * h1) if (w1 * h1) > 0 else float('inf')
            size_score = 0.0
            if 0.5 <= size_ratio <= 2.0:
                size_score = 1.0 - min(abs(1 - size_ratio), 1.0)
            print("similarity", similarity,spatial_score,size_score)

            combined_score = 0.45 * similarity + 0.35 * spatial_score + 0.35 * size_score
        else:
            combined_score = similarity

        if combined_score > best_combined_score:
            best_combined_score = combined_score
            best_similarity = similarity
            best_match_idx = i
    if best_match_idx >= 0 and best_similarity >= similarity_threshold:
        best_match = {
            "match_idx": best_match_idx,
            "similarity": best_similarity,
            "combined_score": best_combined_score,
            "new_box": filtered_vectors[best_match_idx]["box"],
            "new_score": filtered_vectors[best_match_idx]["score"],
            "new_features": filtered_vectors[best_match_idx]["features"],
            "label": filtered_vectors[best_match_idx]["label"]
        }
        print(
            f"Best match found: feature similarity = {best_similarity:.3f}, combined score = {best_combined_score:.3f}")
        return best_match

    print("No sufficiently similar matches found")
    return None

def visualize_detection_results(frame, best_match_box, output_path=None, scale=2):
    """
    visualize detection result
    """
    vis_frame = frame.copy()
    if best_match_box is not None:
        x, y, w, h = best_match_box

        x_original = int(x / scale)
        y_original = int(y / scale)
        w_original = int(w / scale)
        h_original = int(h / scale)

        cv2.rectangle(vis_frame,
                      (x_original, y_original),
                      (x_original + w_original, y_original + h_original),
                      (0, 255, 0), 2)

        cv2.putText(vis_frame, "Best Match",
                    (x_original, y_original - 5),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    (0, 255, 0), 1)

        status_text = "Match_Found"
    else:
        cv2.putText(vis_frame, "No Match Found",
                    (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.7,
                    (0, 0, 255), 2)

        status_text = "No_Match"

    display_height, display_width = vis_frame.shape[:2]
    display_frame = cv2.resize(vis_frame, (display_width * scale, display_height * scale))

    return output_path
def full_image_detect_single(frame, object_name, scale_factor=3):
    """
    resize image and detection
    """
    global prev_obj1_feature
    height, width = frame.shape[:2]

    new_width = int(width * scale_factor)
    new_height = int(height * scale_factor)

    upscaled_frame = cv2.resize(frame, (new_width, new_height))
    upscaled_rgb = cv2.cvtColor(upscaled_frame, cv2.COLOR_BGR2RGB)

    detection_results, feature_vectors = Dino_detect_objects_1(upscaled_rgb, object_name, object_name)

    for vec in feature_vectors:
        if vec["box"] is not None:
            x, y, w, h = vec["box"]
            visualize_detection_results(frame,vec["box"])
            vec["box"] = (int(x / scale_factor),int(y / scale_factor),int(w / scale_factor),int(h / scale_factor))

    if prev_obj1_feature['box'] != (0, 0, 0, 0) and prev_obj1_feature['features'] is not None:
        best_match = compare_feature_with_candidates(prev_obj1_feature, feature_vectors, object_name,
                                                     similarity_threshold=0.6)

        if best_match is not None:
            detected_box = best_match["new_box"]
            best_feature = {
                "features": best_match["new_features"],
                "box": best_match["new_box"]
            }
            return detected_box, best_feature
    else:
        if feature_vectors:
            filtered_vectors = [v for v in feature_vectors if object_name.lower() in v["label"].lower()]

            if filtered_vectors:
                best_candidate = max(filtered_vectors, key=lambda x: x["score"])
                detected_box = best_candidate["box"]
                best_feature = {
                    "features": best_candidate["features"],
                    "box": best_candidate["box"]
                }
                prev_obj1_feature = best_feature
                return detected_box, best_feature

    return None, None

def extract_region_features_dino(region):
    """
    extract_region_features_from groundingdino
    """
    region_rgb = cv2.cvtColor(region, cv2.COLOR_BGR2RGB)

    dummy_text = "object"
    inputs = processor(images=region_rgb, text=[dummy_text], return_tensors="pt")
    inputs = {k: v.to(device) for k, v in inputs.items()}

    with torch.no_grad():
        outputs = model(**inputs)

        if hasattr(outputs, 'last_hidden_state'):
            features = outputs.last_hidden_state[:, 0, :]

        features = F.normalize(features, p=2, dim=1).cpu()

        return features

def make_detection_box(center, w, h):
    """
    create box by centre and w and h
    """
    cx, cy = center
    x = int(cx - w / 2)
    y = int(cy - h / 2)
    return x, y, w, h


def new_robust_dual_object_detection(frame, prev_obj1_box, prev_obj2_box, object1_name, object2_name,projection_point):
    """
    rubost detect two objects
    """
    print("new_robust_dual_object_detection")
    global move_history,prev_obj1_feature,redection_unsuccess,is_redection_success
    height, width = frame.shape[:2]
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    detected = True

    detection_result,feature_vectors = Dino_detect_objects_0(frame_rgb, object1_name, object2_name)
    obj1_box, obj2_box,obj2_boxes, _ = draw_detection_results(
        frame, detection_result, width, height, object1_name, object2_name)

    if prev_obj2_box is not None:
        obj2_box = prev_obj2_box
    elif len(obj2_boxes) > 0:
        obj2_box = obj2_boxes[0]

    if obj1_box is None and prev_obj1_box is None:
        return None,obj2_box, True
    elif prev_obj1_box is not None:
        if obj1_box is not None :
            is_area_consistent, current_dist = is_position_consistent(prev_obj1_box, obj1_box, move_history,2)
            print(f"is_area_consistent:{is_area_consistent},move_history:{move_history}","current_dist",current_dist)
            if is_area_consistent :
                redection_unsuccess = 0
                is_redection_success = True
                if current_dist >= 10:
                    move_history = current_dist
                return obj1_box,obj2_box,True

        upscaled_obj1_box, best_feature = full_image_detect_single(frame, object1_name)
        if upscaled_obj1_box is None:
            w = prev_obj1_box[2]
            h = prev_obj1_box[3]
            obj1_box = make_detection_box(projection_point, w, h)
            is_redection_success = False
            redection_unsuccess += 1
            return obj1_box,obj2_box,True

        is_consistent, new_move_history =is_position_consistent(prev_obj1_box, upscaled_obj1_box, move_history,4)

        if upscaled_obj1_box is not None and is_consistent:
            move_history = new_move_history
            obj1_box = upscaled_obj1_box
            prev_obj1_feature = best_feature
            is_redection_success = True

        else:
            if prev_obj1_box is not None:
                w = prev_obj1_box[2]
                h = prev_obj1_box[3]
                obj1_box = make_detection_box(projection_point,w,h)
                is_redection_success = False
                redection_unsuccess += 1
            else:
                detected = False

    elif prev_obj1_box is None:
        if prev_obj1_feature['box'] == (0, 0, 0, 0) and prev_obj1_feature['features'] is None:
            for item in feature_vectors:
                if item["box"] == obj1_box:
                    new_features = item["features"]
                    break
            prev_obj1_feature = {
                "features": new_features,
                "box": obj1_box
            }

    return obj1_box, obj2_box, detected


def update_center_distance(results):
    if not results or not isinstance(results, list) or len(results) == 0:
        return results

    result = results[0]
    boxes = result.get("boxes")
    if boxes is None:
        return results
    if boxes.shape[0] < 2:
        return results

    boxes_cpu = boxes.cpu()
    box1 = boxes_cpu[0]
    box2 = boxes_cpu[1]

    center1_x = (box1[0].item() + box1[2].item()) / 2.0
    center1_y = (box1[1].item() + box1[3].item()) / 2.0

    center2_x = (box2[0].item() + box2[2].item()) / 2.0
    center2_y = (box2[1].item() + box2[3].item()) / 2.0

    distance = np.sqrt((center2_x - center1_x) ** 2 + (center2_y - center1_y) ** 2)
    result["center_distance"] = distance
    return results

def Dino_detect_objects(frame, object1="white controller", object2="a TV"):
    """
    grounding dino to detect two objects
    """
    text_prompt = f"Detect {object1} and the other is {object2}."

    inputs = processor(images=frame, text=[text_prompt], return_tensors="pt",
                       padding=True, truncation=True).to(device)
    with torch.no_grad():
        outputs = model(**inputs)
    results = processor.post_process_grounded_object_detection(
        outputs,
        inputs.input_ids,
        box_threshold=0.35,
        text_threshold=0.25,
    )
    update_center_distance(results)
    return results[0]


def Dino_detect_objects_0(frame, object1="white controller", object2="a TV", box_threshold=0.35,text_threshold=0.25):

    text_prompt = f"Detect {object1} and the other is {object2}."
    inputs = processor(images=frame, text=[text_prompt], return_tensors="pt",
                       padding=True, truncation=True).to(device)

    with torch.no_grad():
        outputs = model(**inputs)

        if hasattr(model, 'vision_model'):
            visual_features = model.vision_model(inputs.pixel_values).pooler_output

    results = processor.post_process_grounded_object_detection(
        outputs,
        inputs.input_ids,
        box_threshold=box_threshold,
        text_threshold=text_threshold,
    )
    update_center_distance(results)

    feature_vectors = []

    if results[0]["boxes"] is not None and len(results[0]["boxes"]) > 0:
        height, width = frame.shape[:2]

        for i, (box, score, label) in enumerate(zip(results[0]["boxes"], results[0]["scores"], results[0]["labels"])):
            x1, y1, x2, y2 = box.tolist()
            x = int(x1 * width)
            y = int(y1 * height)
            w = int((x2 - x1) * width)
            h = int((y2 - y1) * height)

            if w > 10 and h > 10:

                region = frame[y:y + h, x:x + w]
                features = extract_region_features_dino(region)

                feature_vectors.append({
                    "box": (x, y, w, h),
                    "score": float(score),
                    "label": label,
                    "features": features
                })
    return results[0], feature_vectors

def Dino_detect_objects_1(frame, object1="white controller", object2="a TV", box_threshold=0.35,text_threshold=0.25):

    text_prompt = f"Detect {object1} and the other is {object2}."

    inputs = processor(images=frame, text=[text_prompt], return_tensors="pt",
                       padding=True, truncation=True).to(device)

    with torch.no_grad():
        outputs = model(**inputs)
        if hasattr(model, 'vision_model'):
            visual_features = model.vision_model(inputs.pixel_values).pooler_output
    results = processor.post_process_grounded_object_detection(
        outputs,
        inputs.input_ids,
        box_threshold=box_threshold,
        text_threshold=text_threshold,
    )
    update_center_distance(results)

    feature_vectors = []
    print(len(results))
    for result in results :
        if results[0]["boxes"] is not None and len(results[0]["boxes"]) > 0:
            height, width = frame.shape[:2]

            for i, (box, score, label) in enumerate(zip(result["boxes"], result["scores"], result["labels"])):

                x1, y1, x2, y2 = box.tolist()
                x = int(x1 * width)
                y = int(y1 * height)
                w = int((x2 - x1) * width)
                h = int((y2 - y1) * height)
                if w > 10 and h > 10:

                    region = frame[y:y + h, x:x + w]
                    features = extract_region_features_dino(region)

                    feature_vectors.append({
                        "box": (x, y, w, h),
                        "score": float(score),
                        "label": label,
                        "features": features
                    })
    return results[0], feature_vectors


def draw_detection_results(frame, result, width, height, object1_name, object2_name):

    vis_frame = frame.copy()
    obj1_box = None
    obj2_box = None
    obj1_score = 0.0
    obj2_score = 0.0
    obj2_boxes = []

    for box, score, label in zip(result["boxes"], result["scores"], result["labels"]):
        x1, y1, x2, y2 = box.tolist()
        x = int(x1 * width)
        y = int(y1 * height)
        w = int((x2 - x1) * width)
        h = int((y2 - y1) * height)

        if (object1_name.lower() in label.lower() or fuzzy_match(label, object1_name)) and score > obj1_score:
            obj1_score = score
            obj1_box = (x, y, w, h)

        elif (object2_name.lower() in label.lower() or fuzzy_match(label, object2_name)) :
            obj2_boxes.append((x, y, w, h))
            if score > obj2_score:
                obj2_score = score
                obj2_box = (x, y, w, h)
    return obj1_box, obj2_box,obj2_boxes, vis_frame

def draw_two_detections(frame,box1=None, label1='',box2=None, label2='',color1=(0, 255, 0),  color2=(255, 0, 0),thickness=2):

    vis = frame.copy()
    for box, label, color in [(box1, label1, color1), (box2, label2, color2)]:
        if box is None:
            continue

        x, y, w, h = box
        cv2.rectangle(vis, (x, y), (x + w, y + h), color, thickness)
        if label:
            cv2.putText(vis, label,(x, y - 6),cv2.FONT_HERSHEY_SIMPLEX,0.5, color, 1,lineType=cv2.LINE_AA)
    return vis

def calculate_diagonal_length_in_meters(dx, dy):
    diagonal_length = ((dx) ** 2 + (dy) ** 2) ** 0.5
    coefficient = 0.3
    diagonal_length_in_meters = diagonal_length * coefficient
    return diagonal_length_in_meters


def is_position_consistent(prev_box, new_box, move_history, max_deviation_factor=2):
    x0, y0, w0, h0 = prev_box
    x1, y1, w1, h1 = new_box

    cx0, cy0 = x0 + w0 / 2, y0 + h0 / 2
    cx1, cy1 = x1 + w1 / 2, y1 + h1 / 2
    current_dist = math.sqrt((cx1 - cx0) ** 2 + (cy1 - cy0) ** 2)


    if prev_box is None:
        position_consistent = True
    elif move_history == 10000:
        position_consistent = True
    else:
        position_consistent = current_dist <= move_history * max_deviation_factor

    position_consistent = True

    area1 = w0 * h0
    area2 = w1 * h1

    if area1 > 0:
        area_ratio = area2 / area1
        size_consistent = 0.1 <= area_ratio <= 2
    else:
        size_consistent = False

    is_consistent = position_consistent and size_consistent
    return is_consistent, current_dist

def main():
    indle.midas_setup()
    remapping_motion.move_controller_to_initial_offset()
    global redection_unsuccess , is_redection_success
    projection_point = None
    print("to initial position")
    calibrated = False
    coeff = 0

    while True:
        object1_name = input("input you controller description (default:  grey controller): ") or "grey controller"
        object2_name = input("input you object description  (default: VR screen): ") or "VR screen"
        frame_count = 0
        detection_interval = 90
        tracking_objects = {}
        prev_obj1_box, prev_obj2_box = None, None
        cap = cv2.VideoCapture(1)

        if not cap.isOpened():
            print("cannot open camera")
            return
        print("camera open success")
        for _ in range(30):
            cap.grab()

        while True:

            ret, frame = cap.read()
            if not ret:
                print("no video frame")
                break

            frame_count += 1
            display_frame = frame.copy()
            height, width = frame.shape[:2]


            if frame_count % detection_interval == 1 or len(tracking_objects) == 0:
                print(f"----------------detect in Frame { frame_count} -------------------------------")

                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                controller_pos = remapping_motion.get_visual_controller_pos()

                if not calibrated and controller_pos is not None:
                    projection_point = get_corrected_projection(controller_pos, width, height)
                    if projection_point:
                        cv2.circle(display_frame, projection_point, 5, (255, 0, 0), -1)
                        cv2.putText(display_frame, "redirection point",
                                    (projection_point[0] + 10, projection_point[1] - 10),
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 2)

                print(projection_point)
                obj1_box, obj2_box,detected = new_robust_dual_object_detection(frame_rgb, prev_obj1_box,
                                                                               prev_obj2_box, object1_name,
                                                                               object2_name,projection_point,
                                                                               )


                controller_pos = remapping_motion.get_visual_controller_pos()

                if not calibrated and obj1_box is not None and controller_pos is not None:
                    x, y, w, h = obj1_box
                    center = (x + w // 2, y + h // 2)
                    calibrated = calibrate_first_frame(controller_pos, center, width, height)


                print("obj1_box, obj2_box, ",obj1_box, obj2_box)
                prev_obj1_box, prev_obj2_box = obj1_box, obj2_box

                display_frame = draw_two_detections(display_frame,
                            obj1_box, object1_name,obj2_box,object2_name)
                filename = f"image/frame_{frame_count:04d}.png"
                #cv2.imwrite(filename, display_frame)


            if obj1_box is not None and obj2_box is not None:
                depth_dict = indle.compare_depth(obj1_box, obj2_box, frame, depth_threshold=0.02)
                if depth_dict["need_move"]:
                    distance = calculate_diagonal_length_in_meters(x, y)
                    print("&&&&&&&&START depth moving&&&&&&&&")
                    if coeff == 0:
                        coeff = abs((depth_dict["d1"] -depth_dict["d2"]))/ depth_dict["d1"]
                    remapping_motion.move_controller_in_depth_only(0.3)
                    for _ in range(10):
                        cap.grab()
                else:
                    pass

                if redection_unsuccess >= 10:
                    print("finish moving")
                    return -1

                iou_result = remapping_motion.calculate_distance_and_movement(obj1_box, obj2_box, tolerance=40)
                x,y =iou_result["direction_x"],iou_result["direction_y"]
                print("frame_count","need_move",iou_result["need_move"],iou_result["direction_x"],iou_result["direction_y"])
                if iou_result["need_move"]:
                    print(f"&&&&planar movement:{x},{y}&&&&&")

                    distance = calculate_diagonal_length_in_meters(x,y)*frame_count

                    remapping_motion.move_controller_by_local_direction(x,-y,0,distance*0.8)
                    print("distance", x,-y,distance*0.5)
                    for _ in range(10):
                        cap.grab()
                    continue
                else:
                    pass
                if not depth_dict["need_move"] and not iou_result["need_move"]:
                    print("Finish")
                    break

        cap.release()
        cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
