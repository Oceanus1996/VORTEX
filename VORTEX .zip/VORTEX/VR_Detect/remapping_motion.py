import numpy as np
import openvr
from cam_pos_st import hmd_to_world, init_openvr, get_visual_controller_pos
import script_st

"""
Utility functions for automated control and spatial manipulation of VR controllers
in SteamVR/OpenVR environments.
This module provides foundational tools for VR controller automation in SteamVR environments.
"""

def update_poses_and_get_hmd_matrix():
    poses = openvr.VRCompositor().waitGetPoses()[0]
    hmd_pose = poses[openvr.k_unTrackedDeviceIndex_Hmd]
    if not hmd_pose.bPoseIsValid:
        return None
    m = hmd_pose.mDeviceToAbsoluteTracking
    m = np.array([
        [m[0][0], m[0][1], m[0][2], m[0][3]],
        [m[1][0], m[1][1], m[1][2], m[1][3]],
        [m[2][0], m[2][1], m[2][2], m[2][3]],
        [0,       0,       0,       1     ]
    ], dtype=float)
    return m

def move_controller_in_depth_only(distance=0.2):
    """
    move controller in depth only
    """
    init_openvr()
    hmd_matrix = hmd_to_world()
    if hmd_matrix is None:
        print("no HMD position")
        return None

    controller_pos = get_visual_controller_pos()
    if controller_pos is None:
        return None

    fwd = hmd_matrix[:3, 2]
    up = hmd_matrix[:3, 1]
    fwd = fwd - np.dot(fwd, up) * up
    norm = np.linalg.norm(fwd)
    if norm == 0:
        return None
    fwd /= norm

    new_pos = controller_pos - fwd * distance
    script_st.move_to_pos(new_pos[0], new_pos[1], new_pos[2])
    return tuple(new_pos)

def move_controller_by_local_direction(x, y, z=0, distance=0.3):
    """
    move controller in 3d world by local 2d direction
    """
    init_openvr()
    hmd_m = hmd_to_world()
    if hmd_m is None:
        print("无法获取头盔位姿")
        return None

    pos = get_visual_controller_pos()
    if pos is None:
        return None
    pos = np.array(pos, dtype=float)

    local_vec = np.array([x, y, z], dtype=float)
    norm = np.linalg.norm(local_vec)
    if norm < 1e-6:
        return None
    local_dir = local_vec / norm
    R = hmd_m[:3, :3]
    world_dir = R.dot(local_dir)

    world_dir /= np.linalg.norm(world_dir)
    new_pos = pos + world_dir * distance
    script_st.move_to_pos(new_pos[0], new_pos[1], new_pos[2])
    return tuple(new_pos)


def calculate_distance_and_movement(obj1_box, obj2_box, tolerance=40):
    """
    calculate the distance and decide need move or not
    """
    result = {
        "distance": None,
        "need_move": False,
        "direction_x": 0,
        "direction_y": 0,
        "status": "no two things"
    }

    if obj1_box is None or obj2_box is None:
        return result

    center1_x = obj1_box[0] + obj1_box[2] / 2
    center1_y = obj1_box[1] + obj1_box[3] / 2
    center2_x = obj2_box[0] + obj2_box[2] / 2
    center2_y = obj2_box[1] + obj2_box[3] / 2

    distance = np.sqrt((center2_x - center1_x) ** 2 + (center2_y - center1_y) ** 2)
    dx = center2_x - center1_x
    dy = center2_y - center1_y

    magnitude = np.sqrt(dx ** 2 + dy ** 2)
    if magnitude > 0:
        direction_x = dx / magnitude
        direction_y = dy / magnitude
    else:
        direction_x = 0
        direction_y = 0

    need_move = distance > tolerance

    result = {
        "distance": distance,
        "need_move": need_move,
        "direction_x": direction_x,
        "direction_y": direction_y,
    }

    return result

def move_controller_to_initial_offset(forward_offset=0.7, left_offset=0.2, down_offset=0.2):
    init_openvr()
    hmd_m = hmd_to_world()
    if hmd_m is None:
        return None
    hmd_pos = hmd_m[:3, 3]
    right_vec   =  hmd_m[:3, 0]
    up_vec      =  hmd_m[:3, 1]
    back_vec    =  hmd_m[:3, 2]
    forward_vec = -back_vec

    offset_vec = (
        forward_vec * forward_offset +
        (-right_vec) * left_offset +
        (-up_vec) * down_offset
    )

    target_pos = hmd_pos + offset_vec
    script_st.move_to_pos(target_pos[0], target_pos[1], target_pos[2])

def get_hmd_orientation_angles():
    init_openvr()
    hmd_m = hmd_to_world()
    if hmd_m is None:
        return None

    R = hmd_m[:3, :3]
    if abs(R[2, 0]) < 0.99999:
        pitch = np.arcsin(-R[2, 0])
        yaw = np.arctan2(R[2, 1], R[2, 2])
        roll = np.arctan2(R[1, 0], R[0, 0])
    else:
        pitch = np.arcsin(-R[2, 0])
        yaw = np.arctan2(-R[0, 2], R[1, 2])
        roll = 0

    yaw_deg = np.degrees(yaw)
    pitch_deg = np.degrees(pitch)
    roll_deg = np.degrees(roll)

    return (yaw_deg, pitch_deg, roll_deg)

