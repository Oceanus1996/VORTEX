import mmap
import struct
import time
import numpy as np
import threading
from pynput.keyboard import Key, Listener
"""
This module provides an automated VR controller position movement system
using shared memory and multi-threading for synchronization with a VR driver.
This is the script for driver injection module
"""

x, y, z = 0, 0, 0
stop_event = threading.Event()
listener_instance = None

def move_to_pos(x, y, z):
    global struct_format, shm, target_position, g_start
    struct_format = "fff???"
    shm = mmap.mmap(-1, struct.calcsize(struct_format), "DriverSharedMemory")

    target_position = (x, y, z)
    g_start = False
    stop_event.clear()

    mainloop_thread = threading.Thread(target=mainloop, daemon=True)
    listener_thread = threading.Thread(target=start_listener, daemon=True)

    mainloop_thread.start()
    listener_thread.start()

    time.sleep(2)
    target_position = (x, y, z)
    g_start = True

    mainloop_thread.join()
    listener_thread.join()

    shm.close()

def is_position_close(data, target, threshold=1e-6):
    data_position = np.array(data[:3])
    target_position = np.array(target[:3])
    distance = np.linalg.norm(data_position - target_position)
    return distance < threshold

def sendsharememory(x, y, z, bclick, bdown, bup):
    data = (x, y, z, bclick, bdown, bup)
    packed_data = struct.pack(struct_format, *data)
    shm.seek(0)
    shm.write(packed_data)

def mainloop():
    print("🚀 start to move")
    global x, y, z, g_start, target_position, listener_instance

    while not stop_event.is_set():
        if not g_start:
            time.sleep(0.01)
            continue

        current_position = np.array([x, y, z])
        target_pos = np.array(target_position)
        direction = target_pos - current_position
        distance = np.linalg.norm(direction)

        if distance < 0.01:
            print(f"🎯 arrive: {target_position}")
            g_start = False

            stop_event.set()
            if listener_instance is not None:
                listener_instance.stop()
            return -1

        step_size = 0.01
        move_step = (direction / distance) * step_size

        x += move_step[0]
        y += move_step[1]
        z += move_step[2]

        sendsharememory(x, y, z, False, False, False)
        time.sleep(0.01)

def on_press(key):
    global g_start
    if key == Key.enter:
        g_start = not g_start

def start_listener():
    global listener_instance
    with Listener(on_press=on_press) as listener:
        listener_instance = listener
        listener.join()




