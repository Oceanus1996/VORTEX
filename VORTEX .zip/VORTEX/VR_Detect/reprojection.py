import cam_pos_st
import numpy as np
import cv2
"""
2D-3D Projection and First Frame Calibration Utilities for VR Visualization

This module provides functions to project 3D controller positions onto a 2D image plane
using VR system matrices, and to calibrate and compensate the mapping based on visual
detection feedback in the first frame
"""

first_frame_correction = None
is_first_frame_calibrated = False

def project_3d_to_2d(point_3d, frame_width, frame_height):
    try:

        hmd_pose = cam_pos_st.hmd_to_world()
        left_eye_to_head, _ = cam_pos_st.eye_to_head()
        left_projection, _ = cam_pos_st.get_projection()

        point_3d_homo = np.append(point_3d, 1.0)
        hmd_to_world_inv = np.linalg.inv(hmd_pose)
        head_point = hmd_to_world_inv @ point_3d_homo

        left_eye_to_head_inv = np.linalg.inv(left_eye_to_head)
        eye_point = left_eye_to_head_inv @ head_point

        clip_point = left_projection @ eye_point

        clip_point /= clip_point[3]

        x = int((clip_point[0] + 1.0) * 0.5 * frame_width)
        y = int((1.0 - (clip_point[1] + 1.0) * 0.5) * frame_height)

        return (x, y)
    except Exception as e:
        print(f"Projection calculation error: {e}")
        return None


def calibrate_first_frame(controller_pos, detected_center, frame_width, frame_height):
    """
    Calibrate the first frame: Calculate the offset between the 3D projection and the actual detection position
    """
    global first_frame_correction, is_first_frame_calibrated

    projected_point = project_3d_to_2d(controller_pos, frame_width, frame_height)
    if projected_point is None:
        print("Projection calculation failed, unable to calibrate")
        return False

    dx = detected_center[0] - projected_point[0]
    dy = detected_center[1] - projected_point[1]

    # 存储校正值
    first_frame_correction = {
        "dx": dx,
        "dy": dy,
        "depth": abs(controller_pos[2]),
        "3d_pos": controller_pos,
        "projected": projected_point,
        "actual": detected_center
    }

    is_first_frame_calibrated = True
    print(f"First frame calibration completed: offset = ({dx}, {dy}), depth = {abs(controller_pos[2]):.2f}m")
    return True


def get_corrected_projection(controller_pos, frame_width, frame_height):
    """
    Get the corrected projection point
    """
    global first_frame_correction, is_first_frame_calibrated

    point = project_3d_to_2d(controller_pos, frame_width, frame_height)
    if point is None:
        return None

    if not is_first_frame_calibrated or first_frame_correction is None:
        return point

    current_depth = abs(controller_pos[2])
    initial_depth = first_frame_correction["depth"]

    if current_depth > 1.5 * initial_depth:
        print(f"Use standard projection for long distances: depth={current_depth:.2f}m")
        return point

    corrected_x = point[0] + first_frame_correction["dx"]
    corrected_y = point[1] + first_frame_correction["dy"]

    return (int(corrected_x), int(corrected_y))

def draw_projection_point(frame, point_3d, color=(255, 0, 0), text="投影点"):
    """
    Draw projected points on the image
    """
    height, width = frame.shape[:2]
    vis_frame = frame.copy()

    projected_point = project_3d_to_2d(point_3d, width, height)
    if projected_point is None:
        return vis_frame

    cv2.circle(vis_frame, projected_point, 5, color, -1)
    cv2.putText(vis_frame, text,
                (projected_point[0] + 10, projected_point[1] - 10),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)

    depth = abs(point_3d[2])
    cv2.putText(vis_frame, f"深度: {depth:.2f}m", (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)

    return vis_frame