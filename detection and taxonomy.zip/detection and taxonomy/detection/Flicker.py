import cv2
import numpy as np

import cv2
import numpy as np

import cv2
import numpy as np
from collections import defaultdict

def detect_surface_flicker_brightness(video_path, block_size=32, window=30,
                                      amp_thresh=35, flip_thresh=3, min_duration=30):

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise FileNotFoundError(f"cannot open it {video_path}")

    prev_gray = None
    frame_idx = 0
    brightness_blocks = defaultdict(list)
    block_states = defaultdict(lambda: {"active": False, "start": None, "segments": []})

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        frame_idx += 1

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        H, W = gray.shape

        block_means = []
        for y in range(0, H, block_size):
            for x in range(0, W, block_size):
                block = gray[y:y+block_size, x:x+block_size]
                if block.size == 0:
                    continue
                block_means.append(np.mean(block))

        for b, mean_val in enumerate(block_means):
            brightness_blocks[b].append(mean_val)


            if len(brightness_blocks[b]) >= window:
                seq = brightness_blocks[b][-window:]
                delta = np.diff(seq)

                big_changes = delta[np.abs(delta) > amp_thresh]

                flips = np.sum(big_changes[:-1] * big_changes[1:] < 0)

                is_flicker = flips >= flip_thresh

                state = block_states[b]
                if is_flicker and not state["active"]:
                    state["active"] = True
                    state["start"] = frame_idx - window
                elif not is_flicker and state["active"]:

                    duration = frame_idx - state["start"]
                    if duration >= min_duration:
                        state["segments"].append((state["start"], frame_idx))
                        #print(f"[Flicker] block={b}, frames={state['start']}~{frame_idx}, duration={duration}")
                    state["active"] = False
                    state["start"] = None

    cap.release()

    flicker_blocks = {b: state["segments"] for b, state in block_states.items() if state["segments"]}
    return flicker_blocks
