# ----------------------------------------------------------------------------------------------------------------------#
import base64
from openai import OpenAI
from pythonProject.parse_instruction import client
import torch
from transformers import BlipProcessor, BlipForConditionalGeneration
from PIL import Image

def chatgpt_API_VB12_drift(image_path, obj, controller):
    # Initialize client
    client = OpenAI(
        api_key=r"xxx")

    with open(image_path, "rb") as f:
        img_base64 = base64.b64encode(f.read()).decode("utf-8")

    with open("/monitor/snaps/hover_example.png", "rb") as f:
        example1_base64 = base64.b64encode(f.read()).decode("utf-8")

    with open("/monitor/snaps/IP1_collage.jpg", "rb") as f:
        example2_base64 = base64.b64encode(f.read()).decode("utf-8")

    prompt = f"""
        You are a VR Visualization Bug Detection Assistant.  

        Task Description:  
        You will be given a sequence of continuous frames (possibly stitched into a single large image).  
        Please make your judgment based on the entire sequence as a whole, rather than on individual images.  

        Special Notes:  
        - The scene may contain green markers (small cubes, patches, anchors) and moving controllers (detection tools).  
          These are auxiliary tools and should NOT be considered as bugs.  
        - Only assess bugs related to virtual objects (such as controllers) in the scene.  

        Bug Type Definitions (Drift-related only):  
        1. **Controller Drift (Anchoring Drift)**:  
           If a controller is floating in the air and remains stationary across frames, it is considered problematic.  
           If it moves in a regular pattern, it is not considered a bug.  

        2. **Object Position**:  
           If an object or controller has an abnormal spatial relationship with the ground —  
           for example, partial contact that looks physically implausible, or an unnatural posture  
           inconsistent with gravity — this should be judged as problematic.  

        3. **No Bug (Normal)**:  
           If no drift-related issues exist, classify the scene as “No Bug.”  

        Important Rules:  
        - Do NOT output “Unknown.”  
        - The output must be one of the following two types: **Drift / No Bug**.  
        - Maintain a consistent overall conclusion based on the entire frame sequence.  
        - If the situation is uncertain, lean toward judging it as **Drift**.  

        Output Format (strictly follow this structure):  
        Object description: The shape, posture, and color of {obj}  
        Bug type: Drift / No Bug  
        Reason: A brief one-sentence explanation  
        """

    response = client.chat.completions.create(
        model="gpt-5",  # supports multimodal input
        messages=[
            {
                "role": "system",
                "content": prompt
            },
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Example 1 (Positive - Drift):"},
                    {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{example1_base64}"}},
                    {"type": "text",
                     "text": "Object description: A hand is floating in midair without movement, indicating it’s not a controller.\n"
                             "Bug type: Drift\n"
                             "Reason: The hand is floating in midair without motion and is not a detection controller. "
                             "A stationary floating controller defies physics; therefore, it is classified as drift."}
                ]
            },
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Example 2 (Negative - No Bug):"},
                    {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{example2_base64}"}},
                    {"type": "text",
                     "text": "Object description: A bed is placed in a room.\n"
                             "Bug type: No Bug\n"
                             "Reason: All objects maintain a normal relationship with the ground, with no floating controllers."}
                ]
            },
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Now please analyze the new image:"},
                    {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{img_base64}"}},
                    {"type": "text",
                     "text": f"Object description: The shape, posture, and color of {obj}\n"
                             f"Bug type: Drift / No Bug\n"
                             f"Reason: A brief one-sentence explanation"}
                ]
            }
        ]
    )

    # Output result
    print(response.choices[0].message.content)


Gemini_API = "XXX"

import base64
import google.generativeai as genai

# 初始化 Gemini 客户端
genai.configure(api_key="YOUR_GEMINI_API_KEY")


def gemini_API_VB12_drift(image_path, obj, controller):
    with open(image_path, "rb") as f:
        img_base64 = base64.b64encode(f.read()).decode("utf-8")

    with open("/monitor/snaps/hover_example.png", "rb") as f:
        example1_base64 = base64.b64encode(f.read()).decode("utf-8")

    # 示例图片 2（负例：无异常）
    with open("/monitor/snaps/IP1_collage.jpg", "rb") as f:
        example2_base64 = base64.b64encode(f.read()).decode("utf-8")

    # Prompt
    # Prompt
    prompt = f"""
    You are a VR Visualization Bug Detection Assistant.  

    Task Description:  
    You will receive a sequence of continuous frames (possibly stitched into a single large image).  
    Please make your judgment based on the entire sequence as a whole, rather than on individual images.  

    Special Notes:  
    - The scene may contain green markers (small cubes, patches, anchors) and moving controllers (detection tools).  
      These are auxiliary tools and should NOT be considered bugs.  
    - Only evaluate bugs related to virtual scene objects (tables, chairs, boxes, characters, etc.).  

    Bug Type Definitions (drift-related only):  
    1. **Controller Drift (Anchoring Drift)**:  
       If a controller is floating in midair and remains stationary across frames, it is considered a problem.  
       If the controller moves regularly, it is not considered a bug.  

    2. **Object Position Anomaly**:  
       If the spatial relationship between an object and the ground is abnormal — for example, the object is  
       not fully floating but only partially in contact with the ground in an unrealistic way, or its posture  
       is inconsistent with gravity — it should be judged as a problem.  

    3. **No Bug (Normal)**:  
       If there is no drift-related issue, classify it as “No Bug.”  

    Important Rules:  
    - Do NOT output “Unknown.”  
    - The output must be one of the two categories: **Drift / No Bug**.  
    - Maintain a consistent overall conclusion based on the entire sequence.  
    - If uncertain, lean toward classifying it as **Drift**.  

    Output Format (strictly follow this structure):  
    Object description: The shape, posture, and color of {obj}  
    Bug type: Drift / No Bug  
    Reason: A brief one-sentence explanation  
    """

    # Create Gemini model
    model = genai.GenerativeModel("gemini-1.5-pro")

    # Call Gemini API
    response = model.generate_content(
        [
            prompt,
            # Example 1 (Positive - Drift)
            {"mime_type": "image/png", "data": base64.b64decode(example1_base64)},
            "Example 1 (Positive - Drift): Object description: A hand is floating in midair without movement, indicating it is not a detection controller.\nBug type: Drift\nReason: The controller remains stationary in midair, which violates physical logic.",

            # Example 2 (Negative - No Bug)
            {"mime_type": "image/jpeg", "data": base64.b64decode(example2_base64)},
            "Example 2 (Negative - No Bug): Object description: A bed is placed in a room.\nBug type: No Bug\nReason: All objects maintain normal spatial relationships with the ground, with no floating controllers.",

            # Image to analyze
            "Now please analyze the new image:",
            {"mime_type": "image/png", "data": base64.b64decode(img_base64)},
            f"Object description: The shape, posture, and color of {obj}\nBug type: Drift / No Bug\nReason: A brief one-sentence explanation"
        ]
    )

    print(response.text)


# 载入 BLIP VQA 模型
processor = BlipProcessor.from_pretrained("Salesforce/blip-vqa-base")
model = BlipForConditionalGeneration.from_pretrained("Salesforce/blip-vqa-base").to("cuda" if torch.cuda.is_available() else "cpu")





