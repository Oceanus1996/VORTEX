# ----------------------------------------------------------------------------------------------------------------------#
import base64

from openai import OpenAI
import new_monitor
import base64
import google.generativeai as genai

def chatgpt_API_VB13_misalignment(image_path, obj, target_object):
    # Initialize client
    client = OpenAI(
        api_key=r"xx")

    with open(image_path, "rb") as f:
        img_base64 = base64.b64encode(f.read()).decode("utf-8")

    with open("/monitor/snaps/hover_example.png", "rb") as f:
        example1_base64 = base64.b64encode(f.read()).decode("utf-8")

    with open("/monitor/snaps/IP1_collage.jpg", "rb") as f:
        example2_base64 = base64.b64encode(f.read()).decode("utf-8")

    # 规则提示

    # Prompt
    prompt = f"""
    You are a VR Visualization Bug Detection Assistant.  

    Task Description:  
    You will receive a sequence of continuous frames (possibly stitched into a single large image).  
    Please make your judgment based on the entire sequence as a whole, rather than on individual images.  

    Special Notes:  
    - The scene may contain green markers (small cubes, patches, anchors) and moving controllers (detection tools).  
      These are auxiliary tools and should NOT be considered bugs.  
    - Only evaluate bugs related to virtual scene objects (tables, chairs, boxes, characters, etc.).  

    Bug Type Definitions (drift-related only):  
    1. **Controller Drift (Anchoring Drift)**:  
       If a controller is floating in midair and remains stationary across frames, it is considered a problem.  
       If the controller moves regularly, it is not considered a bug.  

    2. **Object Position Anomaly**:  
       If the spatial relationship between an object and the ground is abnormal — for example, the object is  
       not fully floating but only partially in contact with the ground in an unrealistic way, or its posture  
       is inconsistent with gravity — it should be judged as a problem.  

    3. **No Bug (Normal)**:  
       If there is no drift-related issue, classify it as “No Bug.”  

    Important Rules:  
    - Do NOT output “Unknown.”  
    - The output must be one of the two categories: **Drift / No Bug**.  
    - Maintain a consistent overall conclusion based on the entire sequence.  
    - If uncertain, lean toward classifying it as **Drift**.  

    Output Format (strictly follow this structure):  
    Object description: The shape, posture, and color of {obj}  
    Bug type: Drift / No Bug  
    Reason: A brief one-sentence explanation  
    """

    # Create Gemini model
    model = genai.GenerativeModel("gemini-1.5-pro")

    # Call Gemini API
    response = model.generate_content(
        [
            prompt,
            # Example 1 (Positive - Drift)
            {"mime_type": "image/png", "data": base64.b64decode(example1_base64)},
            "Example 1 (Positive - Drift): Object description: A hand is floating in midair without movement, indicating it is not a detection controller.\nBug type: Drift\nReason: The controller remains stationary in midair, which violates physical logic.",

            # Example 2 (Negative - No Bug)
            {"mime_type": "image/jpeg", "data": base64.b64decode(example2_base64)},
            "Example 2 (Negative - No Bug): Object description: A bed is placed in a room.\nBug type: No Bug\nReason: All objects maintain normal spatial relationships with the ground, with no floating controllers.",

            # Image to analyze
            "Now please analyze the new image:",
            {"mime_type": "image/png", "data": base64.b64decode(img_base64)},
            f"Object description: The shape, posture, and color of {obj}\nBug type: Drift / No Bug\nReason: A brief one-sentence explanation"
        ]
    )

    print(response.text)


# ========== Gemini ==========

Gemini_API = f"xx"
genai.configure(api_key=Gemini_API)
def gemini_API_VB13_misalignment(image_path, obj,target_object):

    with open(image_path, "rb") as f:
        img_base64 = base64.b64encode(f.read()).decode("utf-8")

    with open("/monitor/snaps/hover_example.png", "rb") as f:
        example1_base64 = base64.b64encode(f.read()).decode("utf-8")

    with open("/monitor/snaps/IP1_collage.jpg", "rb") as f:
        example2_base64 = base64.b64encode(f.read()).decode("utf-8")

    # 规则提示
    prompt = f"""
        You are a VR Visualization Bug Detection Assistant.

        Task: Analyze the uploaded image frame sequence and determine whether there exists **Spatial Misalignment** 
        between the hand/controller and **{target_object}** during interaction.

        Definition:
        Spatial Misalignment refers to a positional offset occurring between the hand, controller, or target object 
        during interaction, where alignment or contact is incorrect, resulting in motion that violates physical logic.
        Typical manifestations include:
        - The object should remain stationary but moves together with the hand/controller;
        - The object moves with the hand/controller, but the contact point is floating or unreasonable 
          (e.g., a cup appears to “stick” to the hand);
        - The object’s relative position to the hand/controller shows abnormal offset or penetration.

        Decision Logic:
        1. First, determine whether {target_object} moves in the same direction and magnitude as the hand/controller:
           - If not → classify as **No Spatial Misalignment**.
           - If yes → proceed to the next step.
        2. Check whether the contact point follows physical rules:
           - If contact is reasonable (e.g., proper grasping or pushing, with physically consistent motion) → **No Spatial Misalignment**.
           - If contact is unreasonable (e.g., the hand is not touching, floating, or penetrating the object, 
             yet the object still moves with the hand) → **Spatial Misalignment Exists**.
        3. If the entire scene or camera shifts (causing apparent motion but with the object’s position relative to the background unchanged),
           treat it as **not moving with the hand/controller**.
        4. Green bounding boxes are only localization markers and do NOT represent physical entities — exclude them from evaluation.

        Output Format (strictly follow):
        - Object Description: Briefly describe {target_object} and its interaction within the frames.
        - Moves in Same Direction/Magnitude as Hand/Controller: Yes / No
        - Spatial Misalignment: Exists / Does Not Exist
        - Reason: A one-sentence explanation mentioning keywords such as “reasonable contact / floating / sticking / penetration.”
    """

    # Create Gemini model
    model = genai.GenerativeModel("gemini-1.5-pro")

    # Call Gemini API
    response = model.generate_content(
        [
            prompt,
            # Example 1 (optional, positive)
            {"mime_type": "image/png", "data": base64.b64decode(example1_base64)},
            "Example 1 (Positive - Drift): Object description: A hand floats in midair without movement, indicating it is not a detection controller.\nBug Type: Drift\nReason: The controller remains stationary in midair, violating physical logic.",

            # Example 2 (optional, negative)
            {"mime_type": "image/jpeg", "data": base64.b64decode(example2_base64)},
            "Example 2 (Negative - No Bug): Object description: A bed is placed in a room.\nBug Type: No Bug\nReason: All objects maintain normal spatial relationships with the ground, with no floating controllers.",

            # Image to analyze
            "Now please analyze the new image:",
            {"mime_type": "image/png", "data": base64.b64decode(img_base64)},
            f"Object description: The shape, posture, and color of {obj}\n"
            f"Bug Type: Drift / No Bug\n"
            f"Reason: A brief one-sentence explanation"
        ]
    )

    # Output result
    print(response.text)

