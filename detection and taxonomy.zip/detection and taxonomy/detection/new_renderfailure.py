import cv2
import numpy as np
import os, time
from datetime import datetime
from skimage.metrics import structural_similarity as ssim

DIFF_THRESH = 25
UNIFIED_THRESH = 0.6
CONSEC_FRAMES = 30
SAVE_DIR = "../../render_failures"

def ensure_dir(p):
    if not os.path.exists(p):
        os.makedirs(p, exist_ok=True)

def ts_str():
    return datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]


def detect_rendering_failure(bg_frame, curr_frame,
                             diff_thresh=25,
                             unified_thresh=0.7):
    gray_bg = cv2.cvtColor(bg_frame, cv2.COLOR_BGR2GRAY)
    gray_curr = cv2.cvtColor(curr_frame, cv2.COLOR_BGR2GRAY)

    # --- diff ratio ---
    diff = cv2.absdiff(gray_bg, gray_curr)
    _, diff_mask = cv2.threshold(diff, diff_thresh, 255, cv2.THRESH_BINARY)
    ratio = cv2.countNonZero(diff_mask) / diff_mask.size

    # --- SSIM ---
    gray_bg_small = cv2.resize(gray_bg, (0, 0), fx=0.25, fy=0.25)
    gray_curr_small = cv2.resize(gray_curr, (0, 0), fx=0.25, fy=0.25)
    score, _ = ssim(gray_bg_small, gray_curr_small, full=True)


    M = (ratio + (1 - score)) / 2

    if M > unified_thresh:
        return True, f"failure: ratio={ratio:.2f}, SSIM={score:.3f}, M={M:.3f}"
    else:
        return False, f"yes: ratio={ratio:.2f}, SSIM={score:.3f}, M={M:.3f}"

def open_source(src, start_sec=0.0):
    cap = cv2.VideoCapture(src)
    if not cap.isOpened():
        print("cannot open"); return None, None, None

    fps = cap.get(cv2.CAP_PROP_FPS)
    if not fps or fps != fps or fps <= 1e-3:
        fps = 30.0
    delay_ms = 0

    if isinstance(src, (str, bytes, os.PathLike)) and start_sec > 0:
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or -1
        tgt_frame = int(round(start_sec * fps))
        if total_frames > 0:
            tgt_frame = min(max(0, tgt_frame), total_frames - 1)
        cap.set(cv2.CAP_PROP_POS_FRAMES, tgt_frame)

    ok, first = cap.read()
    if not ok:
        print("cannot open"); cap.release(); return None, None, None
    H, W = first.shape[:2]
    return cap, first, (H, W, fps, delay_ms)

# ========== 主循环 ==========
def monitor_rendering_failure(source, start_sec=0.0):
    ensure_dir(SAVE_DIR)
    cap, bg_frame, meta = open_source(source, start_sec)
    if cap is None: return
    H, W, fps, delay_ms = meta
    consec_fail = 0
    while True:
        ok, frame = cap.read()
        if not ok: break

        fail, reason = detect_rendering_failure(bg_frame, frame, DIFF_THRESH, UNIFIED_THRESH)
        if fail:
            consec_fail += 1
            if consec_fail == CONSEC_FRAMES:
                fname = os.path.join(SAVE_DIR, f"render_fail_{ts_str()}.jpg")
                cv2.imwrite(fname, frame)
                print(f"[FAIL] {reason} → saved: {fname}")
        else:
            consec_fail = 0

    cap.release()
    cv2.destroyAllWindows()
