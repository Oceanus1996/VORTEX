# ----------------------------------------------------------------------------------------------------------------------#
import base64

from openai import OpenAI

import new_monitor
def chatgpt_API_VB11_Penetration(image_path, target_object):
    # Initialize client
    client = OpenAI(
        api_key=r"")

    # 读取目标图像并转为 base64
    with open(image_path, "rb") as f:
        img_base64 = base64.b64encode(f.read()).decode("utf-8")

    # 示例图片 1（正例：穿模）
    with open("/monitor/snap_2/IP1_collage.jpg", "rb") as f:
        example1_base64 = base64.b64encode(f.read()).decode("utf-8")

    # 示例图片 2（负例：不穿模）
    with open("/monitor/snap_2/MR2_collage.jpg", "rb") as f:
        example2_base64 = base64.b64encode(f.read()).decode("utf-8")

    response = client.chat.completions.create(
        model="gpt-5",
        messages=[
            {
                "role": "system",
                "content": (
                    "You are a VR Visualization Bug Detection Assistant. "
                    "Task: Detect **Penetration** occurrences across a sequence of keyframes.\n"
                    "Definition:\n"
                    "- Penetration occurs when a controller or hand enters or passes through the nearest target object "
                    "without proper physical blocking.\n"
                    "- In keyframe sequences, penetration may appear as:\n"
                    "  1. The controller or hand partially entering the target object.\n"
                    "  2. The controller or hand suddenly disappearing when near the object’s surface.\n"
                    "  3. The controller or hand reappearing on the opposite side of the object "
                    "without a visible contact transition.\n\n"
                    "Judgment Rules:\n"
                    "1. If the controller or hand spatially overlaps with the target object, or suddenly disappears/appears near its surface → classify as **Exists**.\n"
                    "2. If the controller or hand remains entirely outside the object or interacts properly on the surface → classify as **Does Not Exist**.\n"
                    "3. If penetration appears in any single frame of the sequence, the entire sequence is considered **Exists**.\n\n"
                    "Output format must be strict JSON, containing the following fields:\n"
                    "{'source': str, 'object_description': str, 'penetration': str, 'reason': str}.\n"
                    "Note: The 'penetration' field must be either 'Exists' or 'Does Not Exist'.\n"
                    "Output JSON only — do not include any additional explanations."
                )
            },

            # -------- Few-shot positive example --------
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Now please analyze the new image:"},
                    {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{example1_base64}"}},
                    {"type": "text", "text": "source=EX1\ntarget object: black tilted bed"}
                ]
            },
            {
                "role": "assistant",
                "content": """{
                  "source": "EX1",
                  "object_description": "black tilted bed",
                  "penetration": "Exists",
                  "reason": "The controller model partially enters below the bed surface, resulting in an unrealistic geometric overlap."
                }"""
            },

            # -------- Few-shot negative example --------
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Now please analyze the new image:"},
                    {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{example2_base64}"}},
                    {"type": "text", "text": "source=EX2\ntarget object: white pillar"}
                ]
            },
            {
                "role": "assistant",
                "content": """{
                  "source": "EX2",
                  "object_description": "white pillar",
                  "penetration": "Does Not Exist",
                  "reason": "The controller remains outside the pillar and moves normally without entering its interior."
                }"""
            },

            # -------- Image to analyze --------
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Now please analyze the new image:"},
                    {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{img_base64}"}},
                    {"type": "text", "text": f"source=IP1\ntarget object: {target_object}"}
                ]
            }
        ]
    )

    result = response.choices[0].message.content
    print(result)


import os, base64
import google.generativeai as genai

genai.configure(api_key="xx")


def gemini_API_VB11_Penetration(image_path, target_object, api_key=f"xx"):

    if api_key is None:
        api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError("Please set GEMINI_API_KEY")

    genai.configure(api_key=api_key, transport="rest")

    def to_b64(p):
        with open(p, "rb") as f:
            return base64.b64encode(f.read()).decode("utf-8")

    img_base64   = to_b64(image_path)
    example1_b64 = to_b64(r"D:\vr1.0\monitor\snap_2\IP1_collage.jpg")
    example2_b64 = to_b64(r"D:\vr1.0\monitor\snap_2\MR2_collage.jpg")

    system_prompt = (
        "You are a VR Visualization Bug Detection Assistant. "
        "Task: Detect **Penetration** in a sequence of keyframes. "
        "Definition: "
        "- When a *moving* controller or hand enters or passes through the nearest target object "
        "without proper physical blocking, it is considered penetration. "
        "- In a sequence, penetration may appear as: "
        "  1) The controller/hand partially enters the target object; "
        "  2) The controller/hand suddenly disappears when near the object surface; "
        "  3) The controller/hand appears on the opposite side but the contact transition is missing. "
        "Rules: "
        "1) If any single frame shows suspected penetration, classify the whole sequence as **Exists**; "
        "2) Simply moving out of the frame boundary does **not** count as penetration; "
        "3) Interaction must occur with the *specified target object* to qualify; "
        "4) The output must be a single JSON object with fields: "
        "{'source': str, 'object_description': str, 'penetration': 'Exists' or 'Does Not Exist', 'reason': str}; "
        "5) Output JSON only — do not include any additional text."
    )

    # 4) Modeling (set system_prompt in system_instruction)
    model = genai.GenerativeModel(
        model_name="gemini-1.5-pro",
        system_instruction=system_prompt
    )

    # 5) Few-shot examples + new input (images passed via inline_data)
    def img_part(b64, mime="image/png"):
        return {"inline_data": {"mime_type": mime, "data": b64}}

    contents = [
        # few-shot positive example
        {
            "role": "user",
            "parts": [
                "Now please analyze the new image:",
                img_part(example1_b64, mime="image/jpeg"),  # if example is jpg, use image/jpeg
                "source=EX1  target object: black tilted bed"
            ],
        },
        {
            "role": "model",
            "parts": [(
                '{"source":"EX1","object_description":"black tilted bed",'
                '"penetration":"Exists","reason":"The controller model partially enters below the bed surface, causing unrealistic geometric overlap."}'
            )],
        },

        # few-shot negative example
        {
            "role": "user",
            "parts": [
                "Now please analyze the new image:",
                img_part(example2_b64, mime="image/jpeg"),
                "source=EX2  target object: white pillar"
            ],
        },
        {
            "role": "model",
            "parts": [(
                '{"source":"EX2","object_description":"white pillar",'
                '"penetration":"Does Not Exist","reason":"The controller remains outside and moves normally without entering the pillar interior."}'
            )],
        },

        # actual image to analyze
        {
            "role": "user",
            "parts": [
                "Now please analyze the new image:",
                img_part(img_base64, mime="image/png"),  # if target is jpg, change to image/jpeg
                f"source=IP1  target object: {target_object}"
            ],
        },
    ]

    # 6) Generation parameters: enforce JSON output, reduce randomness
    gen_cfg = {
        "temperature": 0.2,
        "top_p": 0.8,
        "max_output_tokens": 512,
        "response_mime_type": "application/json",
    }

    # 7) Invoke Gemini model
    try:
        resp = model.generate_content(
            contents,
            generation_config=gen_cfg,
            safety_settings=None,
        )
        print(resp.text)  # should be a single JSON object
    except Exception as e:
        raise RuntimeError(f"Gemini call failed: {e}")
