import cv2
import numpy as np

import cv2
import numpy as np
from scipy.signal import find_peaks

import cv2
import numpy as np

def patch_similarity(p1, p2):
    p1 = p1.astype(np.float32)
    p2 = p2.astype(np.float32)
    p1 -= np.mean(p1)
    p2 -= np.mean(p2)
    denom = (np.linalg.norm(p1) * np.linalg.norm(p2) + 1e-5)
    return np.sum(p1 * p2) / denom

def detect_ghosting_LSS(frame, patch_size=11, search_radius=10, sim_thresh=0.85, step=8):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 100, 200)

    H, W = gray.shape
    ys, xs = np.where(edges > 0)

    ghost_points = 0
    total_points = 0
    half = patch_size // 2

    for (y, x) in zip(ys[::step], xs[::step]):
        if y-half < 0 or y+half >= H or x-half < 0 or x+half >= W:
            continue
        patch = gray[y-half:y+half+1, x-half:x+half+1]

        found_sim = False
        for dy in range(-search_radius, search_radius+1, step):
            for dx in range(-search_radius, search_radius+1, step):
                if dx == 0 and dy == 0:
                    continue
                yy, xx = y+dy, x+dx
                if yy-half < 0 or yy+half >= H or xx-half < 0 or xx+half >= W:
                    continue
                neigh = gray[yy-half:yy+half+1, xx-half:xx+half+1]
                score = patch_similarity(patch, neigh)
                if score > sim_thresh:
                    found_sim = True
                    break
            if found_sim:
                break

        if found_sim:
            ghost_points += 1
        total_points += 1

    score = ghost_points / (total_points + 1e-5)
    return score, {"edge_points": total_points, "ghost_points": ghost_points}
def detect_ghosting_video_LSS(video_path, sample_rate=10, max_frames=30, thresh=0.4, ratio_thresh=0.3):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise FileNotFoundError(f"cannot open it {video_path}")

    frame_idx = 0
    ghost_count = 0
    total_sampled = 0

    while True:
        ret, frame = cap.read()
        if not ret or frame_idx >= max_frames:
            break
        frame_idx += 1

        if frame_idx % sample_rate != 0:
            continue

        score, _ = detect_ghosting_LSS(frame)
        total_sampled += 1
        if score >= thresh:
            ghost_count += 1

    cap.release()

    if total_sampled == 0:
        return "无法判断"

    ratio = ghost_count / total_sampled
    if ratio > ratio_thresh:
        return f"result:  ghosting ({ghost_count}/{total_sampled} ≈ {ratio:.2f})"
    else:
        return f"result: no ghosting ({ghost_count}/{total_sampled} ≈ {ratio:.2f})"


