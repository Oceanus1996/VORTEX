import cv2, numpy as np, os
from datetime import datetime

import cv2, numpy as np, os
from datetime import datetime

# 参数
WIDTH = 720
GLOBAL_THRESH = 10
RESIDUAL_THRESH = 20
CONSEC_FRAMES = 30
SAVE_DIR = "../../jitter_failures"

def ensure_dir(p): os.makedirs(p, exist_ok=True)
def ts(): return datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]

def resize_gray(frame):
    if WIDTH and frame.shape[1] > WIDTH:
        s = WIDTH / frame.shape[1]
        frame = cv2.resize(frame, None, fx=s, fy=s, interpolation=cv2.INTER_AREA)
    return frame, cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

def monitor_jitter_local(source):
    ensure_dir(SAVE_DIR)
    cap = cv2.VideoCapture(source)
    if not cap.isOpened(): print("cannot open"); return
    ok, first = cap.read()
    if not ok: return
    frame_prev, gray_prev = resize_gray(first)

    consec = 0

    while True:
        ok, frame = cap.read()
        if not ok: break
        frame, gray = resize_gray(frame)

        flow = cv2.calcOpticalFlowFarneback(
            gray_prev, gray, None,
            0.5, 3, 15, 3, 5, 1.2, 0
        )
        gray_prev = gray

        vx_mean, vy_mean = flow[...,0].mean(), flow[...,1].mean()
        global_speed = np.hypot(vx_mean, vy_mean)

        residual = flow - np.array([vx_mean, vy_mean])
        residual_mag = np.sqrt(residual[...,0]**2 + residual[...,1]**2)
        residual_std = float(residual_mag.std())

        if global_speed > 10:
            consec = 0
            pass
        elif global_speed > GLOBAL_THRESH and residual_std < RESIDUAL_THRESH:
            status = f"Global shake () g={global_speed:.2f}, res={residual_std:.2f}"

            consec = 0
        elif residual_std > RESIDUAL_THRESH:

            consec += 1
            status = f"LOCAL JITTER {consec}/{CONSEC_FRAMES} res={residual_std:.2f}, g={global_speed:.2f}"
            if consec >= CONSEC_FRAMES:
                fname = os.path.join(SAVE_DIR, f"jitter_{ts()}.jpg")
                cv2.imwrite(fname, frame)
                print(f"[JITTER] residual={residual_std:.2f}, global={global_speed:.2f}")
                consec = 0
        else:
            status = f"OK g={global_speed:.2f}, res={residual_std:.2f}"
            consec = 0


    cap.release(); cv2.destroyAllWindows()
