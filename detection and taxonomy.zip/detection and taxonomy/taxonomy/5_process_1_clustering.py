"""step2"""
from datasets import Dataset
import propocess
import torch

print(torch.cuda.is_available())
print(torch.cuda.device_count())
print(torch.cuda.get_device_name(0) if torch.cuda.is_available() else "No GPU")

""""""
import json

from transformers import pipeline

#vivoport
input = "viveport_review_2.json"
output = "viveport_review_nli_2"
key = "sentence"

#oculus
input = "oculus_sentence.json"
output = "oculus_sentence_nli"
key = "sentence"


classifier = pipeline("zero-shot-classification",
                      model="facebook/bart-large-mnli",
                      device=0)

batch_size = 32
labels = [
    "This review reports a technical problem or bug",
    "This review is positive feedback",
    "This review is neutral and not about problems"
]
with open(input, "r", encoding="utf-8") as f:
    comments = json.load(f)

texts = [c[key] if isinstance(c, dict) else str(c) for c in comments]


dataset = Dataset.from_dict({"text": texts})

def classify_batch(batch):
    outputs = classifier(
        batch["text"],
        candidate_labels=labels,
        batch_size=32,
        truncation=True
    )

    results = {
        "label": [o["labels"][0] for o in outputs],
        "score": [round(o["scores"][0], 3) for o in outputs]
    }
    return results

print("start nli...")
processed_dataset = dataset.map(
    classify_batch,
    batched=True,
    batch_size=32,
    desc="NLI"
)

df = processed_dataset.to_pandas()
df.to_json(f"{output}.json", orient='records', indent=2)
df.to_excel(f"{output}.xlsx", index=False)

