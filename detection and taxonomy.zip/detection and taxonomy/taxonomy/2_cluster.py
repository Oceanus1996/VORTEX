
"""
clustering
"""
import json

import propocess

tag = f"This review reports a technical problem or bug"
path = f"viveport_review_nli_2.json"
all_comments = propocess.read_json_as_list(path)
all_neg_comments = []
for comment in all_comments:
    if comment["label"] == tag:
        all_neg_comments.append({
            "comment": comment["text"],
            "cluster_id":-1,
            "topic_name": -10000
        })
all_neg_comments = [txt for txt, lbl in zip(all_comments["text"], all_comments["label"]) if lbl == tag]
results, cluster_info, labels, embeddings = propocess.vr_semantic_clustering(all_neg_comments)
print("cluster_info",cluster_info)
propocess.write_json(all_neg_comments, "viveport_process_data/viveport_nag_cluster_2.json")
propocess.json_to_excel("viveport_process_data/viveport_nag_cluster_2.json",
                        "viveport_process_data/viveport_nag_cluster_2.xlsx")

with open("viveport_process_data/viveport_nag_cluster_2.json", "r", encoding="utf-8") as f:
    problems = json.load(f)

with open("viveport_process_data/viveport_nag_cluster_1.json", "r", encoding="utf-8") as f:
    all_reviews = json.load(f)


merged = all_reviews + problems


with open("viveport_process_data/viveport_reviews_merged.json", "w", encoding="utf-8") as f:
    json.dump(merged, f, ensure_ascii=False, indent=2)
