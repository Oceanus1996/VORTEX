import json
from sentence_transformers import SentenceTransformer, util
import torch
import propocess
from sentence_transformers import SentenceTransformer, util
import torch

model = SentenceTransformer("all-MiniLM-L6-v2")

taxonomy_labels = [
    # VR specific bugs
    "objects penetrate each other, controller goes through wall",
    "objects float above ground or surface without contact",
    "object shaking or wobbling when still",
    "overlapping surfaces flicker (z-fighting)",

    # Common issues
    "application crashes, freezes, or cannot launch",
    "screen goes black, video fails, or only audio plays",
    "sound missing, distorted, or not in sync with visuals",
    "controllers or buttons not working, misaligned, or tracking incorrectly",
    "game stutters, lags, or has low frame rate",
    "application not working properly on specific VR devices",
    "installation, update, or startup failure after install"
]

# encode taxonomy once
emb_labels = model.encode(taxonomy_labels, convert_to_tensor=True)

def align_theme(theme_words, threshold=0.55):
    """
    find familiar sentence with categories
    """
    theme_text = " ".join(theme_words)
    emb_theme = model.encode(theme_text, convert_to_tensor=True)

    cosine_scores = util.cos_sim(emb_theme, emb_labels)[0]
    top_idx = torch.argmax(cosine_scores).item()
    top_score = float(cosine_scores[top_idx])

    if top_score >= threshold:
        return taxonomy_labels[top_idx], top_score
    else:
        return "new_class", top_score


with open("viveport_process_data/viveport_review_final.json", "r", encoding="utf-8") as f:
    comments = json.load(f)
set_tax = set()
for comment in comments:
    if not comment.get("top3_label"):
        set_tax.add(comment["topic_name"])

tax_sim =[]
print(set_tax)
for tax in set_tax:
    top_idx, top_score = align_theme([tax])
    tax_sim.append(
        {
        "tax":tax,
        "top_idx":top_idx,
        "top_score":top_score
    }
    )
propocess.write_json(tax_sim,"tax_sim_1.json")
propocess.json_to_excel("tax_sim_1.json","tax_sim_1.xlsx")