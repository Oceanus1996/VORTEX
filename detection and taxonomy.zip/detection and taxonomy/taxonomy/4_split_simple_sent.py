# -*- coding: utf-8 -*-
import json, re, pandas as pd
from pathlib import Path

viveport_path = Path("text_review_viveport.json")
oculus_path  = Path("oculus_only_comments.json")

#assert viveport_path.exists(), f"File not found: {viveport_path}"
assert oculus_path.exists(), f"File not found: {oculus_path}"

PUNCTS = r"\.\?\!。！？"

def split_sentences(text: str):
    if not isinstance(text, str):
        return []
    # Normalize whitespace
    t = text.replace("\r", "\n")
    # Replace multiple newlines with a single period + space (to keep semantic boundary)
    t = re.sub(r"\n+", ". ", t)
    t = re.sub(r"\s+", " ", t).strip()
    # If the string lacks terminal punctuation but has long clauses, add a period at end
    if t and t[-1] not in PUNCTS:
        t += "."
    parts = re.split(r"(?<=[\.\!\?。！？])\s+", t)
    # Clean and filter
    out = []
    for p in parts:
        s = p.strip(" \t")
        # Remove stray quotes
        s = s.strip('\"“”\'`')
        # Filter out too-short or meaningless sequences
        if len(s) >= 2 and not re.fullmatch(r"[\.\!\?。！？…·\-–—_~]+", s):
            out.append(s)
    return out

def load_reviews(p: Path):
    with open(p, "r", encoding="utf-8") as f:
        data = json.load(f)
    reviews = []
    if isinstance(data, list):
        for item in data:
            if isinstance(item, str):
                reviews.append(item)
            elif isinstance(item, dict):
                for key in ["描述", "description", "text", "content", "comment"]:
                    if key in item and isinstance(item[key], str):
                        reviews.append(item[key])
                        break
                else:
                    texts = [str(v) for v in item.values() if isinstance(v, str)]
                    reviews.append(" ".join(texts))
    else:
        reviews = [str(v) for v in data.values() if isinstance(v, str)]
    return reviews

def split_file_to_df(p: Path, source_name: str):
    reviews = load_reviews(p)
    rows = []
    for ridx, text in enumerate(reviews):
        sents = split_sentences(text)
        for sidx, sent in enumerate(sents):
            rows.append({
                "source": source_name,
                "review_index": ridx,
                "sentence_index": sidx,
                "sentence": sent
            })
    return pd.DataFrame(rows)

# Viveport
df_vive = split_file_to_df(viveport_path, "viveport")

df_ocul = split_file_to_df(oculus_path, "oculus")
print("len(df_ocul)",len(df_ocul))
df_all = pd.concat([df_vive, df_ocul], ignore_index=True)

df_all = df_ocul
# --------- output ----------
out_json = Path("oculus_sentence.json")
out_excel = Path("oculus_sentence.xlsx")

with open(out_json, "w", encoding="utf-8") as f:
    json.dump(df_all.to_dict(orient="records"), f, ensure_ascii=False, indent=2)

df_all.to_excel(out_excel, index=False)

print(f"Saved: {out_json}")
print(f"Saved: {out_excel}")
print(df_all.head(5))
