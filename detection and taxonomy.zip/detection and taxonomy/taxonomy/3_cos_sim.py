import json

import numpy as np
from sentence_transformers import SentenceTransformer, util
import torch
import propocess
"""

（(1) Split the text into short sentences, and use NLI to extract problem sentences — other documents are fine (explain this step).
(2) Classify based on the existing taxonomy using the BGE model to calculate similarity scores; a similarity threshold of 0.4 was obtained.
(3) Sentences that were not matched are then clustered naturally; this resulted in 4,100 noise points and around 69 clusters.
(4) Extract keywords from each cluster using TF-IDF.
(5) Compare sentences formed by combining these keywords with the existing taxonomy using cosine similarity:
 Scores above 0.4 are automatically merged.
Scores between 0.32–0.4 are manually reviewed.
Scores below 0.32 are treated as new categories (some manually verified).
(6) The remaining noise samples are again clustered naturally — the iteration continues (clustering is limited to a maximum of three rounds).
(7) Extract all visual-related issues (possibly followed by another NLI pass).

Detailed clustering process:

First classification:
Used the existing taxonomy with the BGE model to compute similarity (threshold = 0.4) → initial assignment.

First clustering:
Samples below 0.4 underwent natural clustering to obtain related topic entries.
Then used “add-cluster” logic to see how new classes integrate.
By the third iteration, new cluster prompts were obtained and used for further clustering.

Compared cluster centers from taxonomy-based classes with those from natural clustering, applied a threshold to decide whether to merge existing classes or create new ones (documented in another file).

Second clustering:
Performed another clustering pass on the noise points from the first natural clustering → yielded 32 clusters and about 900 noise points.

Third clustering:
Again clustered remaining noise points → yielded 14 clusters and about 400 noise points.

"""
def step_1(taxonomy_labels,input = r"viveport_reviews_merged.json",output = r"viveport_review_taxonomy_classified"):
    """first clusting"""
    model = SentenceTransformer("all-MiniLM-L6-v2")
    def classify_with_taxonomy(text):

        if not text or not isinstance(text, str):
            return None

        # 编码
        emb_text = model.encode(text, convert_to_tensor=True)
        emb_labels = model.encode(taxonomy_labels, convert_to_tensor=True)

        # 计算相似度
        cosine_scores = util.cos_sim(emb_text, emb_labels)[0]

        # 获取top3
        top_k = torch.topk(cosine_scores, k=3)
        values = top_k.values.cpu().numpy()
        indices = top_k.indices.cpu().numpy()

        return {
            "top1_label": taxonomy_labels[indices[0]],
            "top1_score": round(float(values[0]), 3),
            "top2_label": taxonomy_labels[indices[1]],
            "top2_score": round(float(values[1]), 3),
            "top3_label": taxonomy_labels[indices[2]],
            "top3_score": round(float(values[2]), 3)
        }

    with open(input, "r", encoding="utf-8") as f:
        comments = json.load(f)

    for i, comment in enumerate(comments):
        text = comment.get("comment") or comment.get("sentence") or comment.get("comment", "")

        if text:
            taxonomy_result = classify_with_taxonomy(text)
            if taxonomy_result:
                comment.update(taxonomy_result)
            else:
                print(f"failure categories {i} comments")
        else:
            print(f"empty{i}comments")


        if (i + 1) % 100 == 0:
            print(f"handle {i + 1}/{len(comments)}")

    output_file = f"{output}.json"
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(comments, f, ensure_ascii=False, indent=2)

    print(f"✅ saved {output_file}")

    try:
        propocess.json_to_excel(output_file, f"{output}.xlsx")

    except Exception as e:
        print(f"{e}")

    if comments:
        top1_labels = {}
        for comment in comments:
            if "top1_label" in comment:
                label = comment["top1_label"]
                top1_labels[label] = top1_labels.get(label, 0) + 1

        for label, count in sorted(top1_labels.items(), key=lambda x: x[1], reverse=True):
            print(f"  {label[:50]}... : {count}")


def step_2(path = r"viveport_review_taxonomy_classified.json",output= "viveport_review_final"):
    with open(path, "r", encoding="utf-8") as f:
        comments = json.load(f)

    known, unknown = [], []
    for c in comments:
        if c.get("top1_score", 0) < 0.4:
            unknown.append(c)
        else:
            known.append(c)

    print(f"✅ known: {len(known)} , unknown: {len(unknown)} ")


    unknown_texts = [c["comment"] for c in unknown]
    results, _, _, _ = propocess.vr_semantic_clustering(unknown_texts,10)

    merged = known + results
    print("type",type(results),type(known))

    with open(f"{output}.json", "w", encoding="utf-8") as f:
        json.dump(merged, f, ensure_ascii=False, indent=2, default=to_builtin)
    propocess.json_to_excel(f"{output}.json",
                            f"{output}.xlsx")
    print(f"✅ saved {output}.xlsx")

def to_builtin(obj):
    if isinstance(obj, (np.integer,)):
        return int(obj)
    elif isinstance(obj, (np.floating,)):
        return float(obj)
    elif isinstance(obj, (np.ndarray,)):
        return obj.tolist()
    else:
        return str(obj)

#最初的分类法
taxonomy_labels = [
        # VR specific bugs
    # VR specific bugs
    "objects penetrate each other, controller goes through wall",
    "objects float above ground or surface without contact",
    # "controller or object misaligned with real-world position",
    "object shaking or wobbling when still",
    #"overlapping surfaces flicker (z-fighting)",
    "scene collapses into flat plane, no 3D depth",
    # "blurred or duplicated edges in VR view",

        # Common issues
        "application crashes, freezes, or cannot launch",
        "screen goes black, video fails, or only audio plays",
        "sound missing, distorted, or not in sync with visuals",
        "controllers or buttons not working, misaligned, or tracking incorrectly",
        "game stutters, lags, or has low frame rate",
        "application not working properly on specific VR devices",
        "installation, update, or startup failure after install"
    ]

#获得新的taxonomy_labels，对上次失败的语句进行二次探测，看看他怎么样
taxonomy_labels_v2 = [
    # VR specific bugs
    "objects penetrate each other, controller goes through wall",
    "objects float above ground or surface without contact",
    "controller or object misaligned with real-world position",
    "object shaking or wobbling when still",
    "overlapping surfaces flicker (z-fighting)",
    "scene collapses into flat plane, no 3D depth",
    "blurred or duplicated edges in VR view",

    # Common issues
    "application crashes, freezes, or cannot launch",              # 主题12/13/14/16
    "screen goes black, video fails, or only audio plays",         # 黑屏/视频失败
    "sound missing, distorted, or not in sync with visuals",       # 主题21/36/37
    "controllers or buttons not working, misaligned, or tracking incorrectly", # 主题22/23/66
    "game stutters, lags, or has low frame rate",                  # 主题32/42
    "application not working properly on specific VR devices",     # 主题12/13/66
    "installation, update, or startup failure after install",      # 主题15/27/39
    "unintuitive or broken user interface / menu navigation",      # 主题28/29/31
    "VR locomotion or movement system broken or uncomfortable",    # 主题45/46
    "visual discomfort or eye strain from graphics or calibration",# 主题33
    "false positives / antivirus blocks game files or executables" # 主题49
]

# all_comments = propocess.read_json_as_list("viveport_review_final.json")
# new_coments = [comment for comment in all_comments if not comment.get("top3_label")]
#
# propocess.write_json(new_coments,"new_cluster_v2.json")
#
# propocess.json_to_excel("new_cluster_v2.json","new_cluster_v2.xlsx")

# input = r"new_cluster_v2.json"
# output = r"new_cluster_taxonomy_v2.json"
# step_1(taxonomy_labels_v2,input,output)

def round2_step_1(input="viveport_review_taxonomy_classified.json",output = "round2_cluster"):
    with open(input, "r", encoding="utf-8") as f:
        comments = json.load(f)

    known, unknown = [], []
    for c in comments:
        if c.get("top1_score", 0) < 0.4 and c.get("topic_name") == "未分类/噪声":
            unknown.append(c)
    print(f"✅ known: {len(known)} 条, unknow: {len(unknown)} 条")
    unknown_texts = [c["comment"] for c in unknown]
    results, _, _, _ = propocess.vr_semantic_clustering(unknown_texts,10)

    merged = known + results
    print("type",type(results),type(known))
    outputfile=f"{output}.json"
    with open(outputfile, "w", encoding="utf-8") as f:
        json.dump(merged, f, ensure_ascii=False, indent=2, default=to_builtin)
    propocess.json_to_excel(outputfile, f"{output}.xlsx")
    print(f"✅ saved {outputfile}")

def round3_step_1(input="round2_cluster.json.json",output = "round3_cluster.json"):
    with open(input, "r", encoding="utf-8") as f:
        comments = json.load(f)
    known, unknown = [], []
    for c in comments:
        if c.get("topic_name") == "未分类/噪声":
            unknown.append(c)
    print(f"✅ known: {len(known)}  unknown: {len(unknown)} ")
    unknown_texts = [c["comment"] for c in unknown]
    results, _, _, _ = propocess.vr_semantic_clustering(unknown_texts,10)


    merged = known + results
    print("type",type(results),type(known))

    outputfile = f"{output}.json"
    with open(outputfile, "w", encoding="utf-8") as f:
        json.dump(merged, f, ensure_ascii=False, indent=2, default=to_builtin)
    propocess.json_to_excel(outputfile, f"{output}.xlsx")
    print(f"✅ saved {output}")

round3_step_1("round2_cluster.json","round3_cluster.json")



step_1(taxonomy_labels,"oculus_sentence.json",output="oculus_taxonomy_classified.json")

step_2("oculus_taxonomy_classified.json","oculus_cluster_v1")



step_2("oculus_taxonomy_classified.json","test_oculus")
step_2("viveport_process_data/viveport_review_taxonomy_classified.json","viveport_test")


step_1(taxonomy_labels,r"oculus_sentence.json",r"oculus_sentence_taxonomy")
step_2(r"oculus_sentence_taxonomy.json","oculus_recluster")

step_1(taxonomy_labels)
step_2()

round2_step_1("oculus_recluster.json","oculus_round2_cluster")
round3_step_1("oculus_round2_cluster.json","oculus_round3_cluster")

round2_step_1("viveport_review_final.json","viveport_review_final_round2")
round3_step_1("viveport_review_final_round2.json","viveport_review_final_round3")